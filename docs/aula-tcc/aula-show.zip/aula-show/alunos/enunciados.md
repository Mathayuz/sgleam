# Oficina SHOW

Trabalhem em duplas. O foco dos exercícios é usar a SHOW: produzir o modelo inicial em `init`, tratar mensagens em `update` e construir a interface em `view`. As funções auxiliares já estão implementadas. Não é necessário reescrever as regras de login, validação, duplicação ou leitura do TXT.

Em cada exercício:

1. Esbocem a tela e identifiquem o que muda. Justifiquem os tipos Model e Msg fornecidos na base.
2. Especifiquem o resultado de init e os exemplos de update antes de implementar.
3. Implementem init e update. Nos exercícios 1 e 2, executem os testes essenciais fornecidos; no exercício 3, confiram o fluxo na interface.
4. Construam a view, associem eventos às mensagens e verifiquem a interação no playground.

Os valores provisórios nas lacunas servem apenas para a base compilar; não são soluções corretas. Os poucos testes de init/update dos exercícios 1 e 2 identificam o que falta implementar. O exercício 3 não contém testes automatizados. Testes aprovados não substituem a conferência visual e de interação da view.

## Exercício 1 — Gerador de login e e-mail

Tempo: 14h05–14h23. Base: `exercicio_1.gleam`.

Construam uma interface com dois inputs: nome completo e domínio sem @. Cada edição deve atualizar a prévia do e-mail. Nome e domínio vazios devem produzir uma orientação, já calculada pelas funções fornecidas.

**Já está pronto:** `login`, `email`, `previa`, tipos Model/Msg e a ligação da aplicação em `main`.

**Implementem:**

- `init`: começar com nome vazio e domínio `uem.br`.
- `update`: tratar `NomeAlterado` e `DominioAlterado`, preservando o outro campo.
- `view`: usar `text_input.new`, `text_input.on_input`, `text.new` e `layout.column` para mostrar os campos e `previa(model)`.

A função `login` fornecida usa as iniciais das partes anteriores ao último nome e o último nome, em minúsculas, limitando o resultado inteiro a oito caracteres. Ignora espaços comuns extras; partículas contam. O escopo são nomes com letras ASCII e espaços comuns. A validação do domínio é didática, não um validador geral de e-mail.

| Nome | Domínio | Prévia |
|---|---|---|
| Ana Maria Silva | uem.br | amsilva@uem.br |
| Ana | uem.br | ana@uem.br |
| Ana de Souza | uem.br | adsouza@uem.br |
| Ana Maria Nascimento | uem.br | amnascim@uem.br |

**Verifiquem:** o estado inicial; edição de cada campo sem apagar o outro; prévia atualizada; orientação ao apagar um campo. Os exemplos de update já verificam a preservação do outro campo. Expliquem por que a prévia pode ser calculada em vez de guardada no Model.

O programa gera identificadores; não implementa autenticação, senha ou criação de contas em servidor.

## Exercício 2 — Lista sem repetição

Tempo: 14h23–14h38. Evoluam o exercício 1 ou usem `exercicio_2.gleam`, que contém as regras prontas e novas lacunas em init/update/view.

Acrescentem botão Adicionar, lista de cadastrados e mensagem de feedback. Uma inclusão válida acrescenta o endereço ao final da lista; uma tentativa repetida mantém a lista e mostra o motivo.

**Já está pronto:** geração e validação de e-mail, `adicionar`, `cadastrar` e `previa`. `cadastrar(model)` devolve o modelo com a lista e o aviso atualizados. Neste exercício, a lista de endereços reservados é vazia.

**Implementem:**

- `init`: nome vazio, domínio `uem.br`, lista e aviso vazios.
- `update`: atualizar os campos e limpar o aviso ao editar; ao receber `Adicionar`, usar `cadastrar(model)`.
- `view`: mostrar inputs, prévia, botão com `button.on_press(Adicionar)`, aviso e todos os endereços de `model.emails`. Usem `list.map` para criar os textos da lista.

A comparação dos endereços já é normalizada em minúsculas e sem espaços nas pontas. Mesmo login com domínio diferente é outro endereço. Nomes distintos que gerem o mesmo endereço representam conflito. Não criem sufixos automaticamente.

**Verifiquem:** primeira inclusão, repetição, campo inválido, edição sem apagar a lista e limpeza do aviso ao editar. Executem os exemplos essenciais de inclusão, repetição e preservação da lista ao editar. A lista permanece somente durante a sessão; recarregar a página a reinicia.

## Exercício 3 — Lista externa de e-mails existentes

Tempo: 14h48–15h00. Base: `exercicio_3.gleam`.

O TXT contém `amsilva@uem.br` e `ana@uem.br`, um por linha. A aplicação não deve cadastrar endereços dessa lista nem repetir os incluídos localmente.

**Já está pronto:** `carregar`, que descreve a tarefa de obtenção do TXT e produz `Recebidos`; `ler_emails`, que interpreta o texto; regras de cadastro e bloqueio enquanto a lista está indisponível; tipos, main e a interface do exercício anterior. Não é necessário implementar o parser ou a regra de duplicação.

**Completem as lacunas:**

- `init`: devolver o modelo inicial com estado `Carregando` e a tarefa `carregar()`.
- `update`: em `Recebidos(Ok(conteudo))`, guardar `Pronto(ler_emails(conteudo))`; em erro, mudar para `Falhou`; em `Recarregar`, voltar a `Carregando` e devolver uma nova tarefa `carregar()`.
- `view`: calcular quando habilitar Adicionar e Carregar novamente usando `button.enabled`; mostrar uma mensagem para cada estado. Adicionar só fica habilitado em `Pronto`; a nova tentativa fica desabilitada durante o carregamento.

Mensagens sem novo efeito devolvem `task.none()`. O bloqueio também existe na regra de cadastro: não basta desabilitar o botão.

**Confiram no playground:** carregamento inicial, endereço reservado, endereço disponível, repetição local, falha e nova tentativa. Confiram os botões, os avisos e as duas listas no playground: os endereços carregados do TXT e os cadastrados nesta sessão aparecem separadamente.

Ao executar `main()` no playground integrado, `app.run` usa o executor real e solicita `emails-existentes.txt` por HTTP. A URL é relativa à página do playground: o TXT deve estar hospedado ao lado dela. As requisições são sequenciais e têm timeout de 10 segundos. O cadastro permanece bloqueado até receber a lista.

Para demonstrar falha real, o docente pode trocar temporariamente a URL por um arquivo inexistente e executar novamente; para recuperar, deve restaurar a URL e reiniciar. O botão Carregar novamente repete a URL do programa. Se a resposta for muito rápida, Carregando pode aparecer brevemente; os testes verificam o estado independentemente da duração visual.

## Execução

No playground, carreguem um arquivo por vez e chamem `main()`. Para executar os testes no terminal, entrem na pasta do arquivo:

```sh
sgleam check exercicio_1.gleam
sgleam test exercicio_1.gleam
```

Repitam os testes para o exercício 2. Para o exercício 3, usem `sgleam check exercicio_3.gleam` e confiram a execução no playground. As bases compilam, mas há falhas esperadas nos testes de init/update dos exercícios 1 e 2 até completar as lacunas. Avisos de imports e argumentos ainda não usados são esperados nas bases.

Ao final de cada tentativa, haverá resolução coletiva. Os exemplos contador e texto ficam disponíveis desde o início; os gabaritos dos exercícios serão apresentados na resolução. A avaliação final é individual: respondam com base no que fizeram e na ajuda recebida.
