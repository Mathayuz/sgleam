// Static localhost server for an already compiled playground, including the
// isolation headers required by SharedArrayBuffer. No Rust build or JSR fetch.
// deno run --allow-read --allow-net tools/servir-aula.ts dist
const root = Deno.args[0] ?? "dist";
const headers = {
  "Cross-Origin-Opener-Policy": "same-origin",
  "Cross-Origin-Embedder-Policy": "require-corp",
  "Cross-Origin-Resource-Policy": "same-origin",
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
};
const mime: Record<string, string> = {
  html: "text/html; charset=utf-8",
  js: "text/javascript; charset=utf-8",
  wasm: "application/wasm",
  css: "text/css; charset=utf-8",
  txt: "text/plain; charset=utf-8",
  json: "application/json",
  svg: "image/svg+xml",
  png: "image/png",
};

Deno.serve({ hostname: "127.0.0.1", port: 8000 }, async (request) => {
  if (request.method !== "GET" && request.method !== "HEAD") {
    return new Response("Método não permitido", { status: 405, headers });
  }
  let path: string;
  try {
    path = decodeURIComponent(new URL(request.url).pathname);
  } catch {
    return new Response("URL inválida", { status: 400, headers });
  }
  const parts = path.split("/").filter(Boolean);
  if (
    parts.some((part) => part === "." || part === ".." || /[\\:\0]/.test(part))
  ) {
    return new Response("Caminho inválido", { status: 400, headers });
  }
  if (parts.length === 0) parts.push("sgleam.html");
  try {
    const content = await Deno.readFile(`${root}/${parts.join("/")}`);
    const extension = parts.at(-1)?.split(".").at(-1) ?? "";
    return new Response(request.method === "HEAD" ? null : content, {
      headers: {
        ...headers,
        "Content-Type": mime[extension] ?? "application/octet-stream",
      },
    });
  } catch (error) {
    return new Response("Arquivo não encontrado", {
      status: error instanceof Deno.errors.NotFound ? 404 : 500,
      headers,
    });
  }
});
